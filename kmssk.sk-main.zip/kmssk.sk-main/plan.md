# Development Plan — kmssk.sk (Static PHP/HTML/CSS/Vanilla JS + PHP API + MySQL)

## 1) Objectives
- Deliver a polished, fast, crawlable, multilingual website for **Komunita moslimov v Slovenskej republike (KMS)**, compatible with **Websupport shared hosting** (Apache/PHP/MySQL) with **no build step**.
- Provide a reliable dynamic core via PHP+MySQL:
  - Announcements (incl. homepage popup)
  - Events/Calendar (**embeddable via iframe on ayan.sk only**)
  - Contact form (**save to DB + email notification**) with **SMTP configured via `api/config.php`** (fallback to PHP `mail()` when SMTP is not configured)
  - Secure `/webadmin/` panel for CRUD + archive.
- Implement i18n via `/i18n/*.json` with smooth transitions; Arabic uses **RTL text direction only** (no mirrored layout).
- Ensure a **zero-manual-step first-run install** on Websupport: after uploading, the site should be functional by only filling DB credentials (no SSH, no phpMyAdmin import).
- Provide a production-friendly **Page Editor** inside `/webadmin/`:
  - Live preview of the real site
  - Click-to-edit **page body** content (text + images) with per-language overrides (SK/EN/DE/RU/AR)
  - Keep menu/navigation/system labels controlled by `/i18n/*.json` (not edited in the visual editor).
- Deliver clean, SEO-friendly URLs (no `.html` in the address bar) with proper redirects and canonicalization.
- Add a GDPR-style **cookie/privacy consent banner**:
  - Shown once per visitor, localized (SK/EN/DE/RU/AR)
  - Links to the Privacy Policy page
  - Does not interfere with embed mode or the admin Page Editor.
- Harden against crawlers and accidental data exposure:
  - Disallow crawling of `/api/` and `/webadmin/`
  - Block direct access to sensitive file types (`.sql/.log/.md/.env/.txt`)
  - Ensure clean canonical URLs to avoid duplicate-indexing.
- Package the final site as a **single zip** ready for upload to Websupport and include deployment documentation.

**Current status (UPDATED):** Objectives achieved; deployable zip is ready at `/app/kmssk-sk-website.zip` (~1.8MB). Critical production-path issues have been fixed and independently verified via **real Apache (port 8899)** + Playwright + `testing_agent_v3`:
- Clean-URL redirect loop on Apache: fixed via `%{THE_REQUEST}` guards (iteration_6).
- Contact form not working + editor non-editable in production: fixed and verified (iteration_7).
- Public-facing “Embed this calendar on another site” section removed from `/activities` (iteration_7).
- SMTP settings UI removed per user request; SMTP config moved to `api/config.php`; `api/admin_settings.php` removed (iteration_8).
- **Mail delivery hardening (latest):** Replaced custom SMTP socket mailer with **PHPMailer** (vendored, no Composer) and added `mail_error` persistence + admin tooltip visibility for failed sends (iteration_9).

**Important note:** Final acceptance still depends on the user re-uploading the updated zip to Websupport and confirming behavior on their real domain/DB/mailbox.

---

## 2) Implementation Steps

### Phase 0 — Project skeleton + local preview setup (COMPLETED)
**User stories (completed)**
1. As a developer, I can run the site locally with PHP and a local MySQL-compatible server.
2. As a developer, I can keep the final deployable structure identical to Websupport hosting.
3. As an admin, I can later configure production DB credentials without code changes.
4. As a user, pages load quickly with optimized static assets.
5. As a crawler, the site is discoverable via sitemap/robots.

**Steps (implemented)**
- Created deliverable directory `/app/site` with required structure:
  - `/api`, `/assets/{css,js,img,fonts}`, `/i18n`, `/uploads`, `/webadmin`, root pages + `.htaccess`, `robots.txt`, `sitemap.xml`.
- Sandbox-only: installed **PHP 8.2 + extensions** (`pdo_mysql`, `mysqli`, etc.) and **MariaDB server**.
- Sandbox-only: repurposed supervisor programs (via `/etc/supervisor/conf.d/zz_php_site.conf`) to serve the same docroot `/app/site`:
  - `php -S 0.0.0.0:3000 -t /app/site /app/site/router.php` (frontend)
  - `php -S 0.0.0.0:8001 -t /app/site /app/site/router.php` (backend)
  This matches platform ingress routing while still serving the same real PHP site.
- Implemented `/api/config.php` with DB credentials configurable via env vars or direct constants.
- Added `router.php` as a **dev-only shim** because `php -S` does not read `.htaccess` rewrite rules; Apache/Websupport ignores `router.php`.

**Additional local testing harness (COMPLETED, dev-only)**
- Added a real Apache vhost for `.htaccess`-accurate testing:
  - `/etc/apache2/conf-enabled/kmssk-test.conf` serving `/app/site` on port **8899**.

---

### Phase 1 — Core POC (Isolation): PHP↔MySQL↔API + mail() (COMPLETED)
**Core workflow proven:** DB connection + CRUD for announcements/events + admin auth + contact submit (DB write + email).

**Steps (implemented)**
- Created MySQL schema (production-ready):
  - `admin_users`, `announcements`, `events`, `contact_submissions`, `settings`.
- Implemented core endpoints:
  - Public: `announcements_list.php`, `announcements_popup.php`, `events_list.php`, `contact_submit.php`
  - Auth: `admin_login.php`, `admin_logout.php`, `admin_me.php`
  - Admin CRUD: `admin_announcements.php`, `admin_events.php`, `admin_contacts.php`, `admin_upload.php`.

---

### Phase 1B — Production critical bug fix: schema missing on real Websupport DB (COMPLETED)
**Fix (implemented)**
1. **Auto-install schema on first run** (`/api/db.php`) including admin creation + seeds.
2. **Fix MySQL host/port ambiguity** (`localhost` socket vs TCP): translate to `127.0.0.1` internally.
3. `.htaccess` blocks sensitive extensions (incl. `.txt`) to protect `api/admin_credentials.log`.
4. Schema parsing hardening.

---

### Phase 2 — V1 site build (public pages + i18n + popup + calendar embed) (COMPLETED)
- Built 8 public pages + 404.
- Implemented multilingual loader with smooth transitions.
- Implemented homepage popup (announcement-based).
- Implemented events calendar + embed mode `?embed=1`.

---

### Phase 3 — Webadmin panel (secure CRUD + archive) (COMPLETED)
- Implemented `/webadmin/` login + dashboard + CRUD pages.
- Added session auth guard + CSRF protection.

---

### Phase 3B — Admin UX upgrade: sidebar reorder + SVG icons (COMPLETED)
- Sidebar order and icons implemented:
  - Správy → Oznamy → Kalendár → Editor stránok → Nastavenia.

---

### Phase 3C — Site Editor (“Editor stránok”) (COMPLETED, FIXED/VERIFIED)
**Architecture (implemented)**
- Added `content_overrides` table.
- Public read endpoint: `GET /api/content_overrides.php`.
- Admin mutations: `POST /api/admin_content.php`.
- Public bridge script: `/assets/js/editor-bridge.js` (active only under `?admin_edit=1` inside iframe).
- Admin UI: `/webadmin/editor.php` with per-language rich-text editing + image replace/revert.

**Critical bug fix (COMPLETED; verified iteration_7): Home page edit mode broken**
- **Problem:** Clicking Home-page elements in the editor iframe did nothing.
- **Root cause:** `.htaccess` legacy redirect for `index.html` used `/?` which **stripped the query string**, removing `?admin_edit=1`.
- **Fix:** Change redirect substitution to `/` so Apache preserves query strings.
- **Verification:** Playwright + real Apache confirmed click-to-edit + image panel works on Home and other pages.

---

### Phase 3D — Settings (“Nastavenia”) + SMTP / mail delivery (UPDATED: COMPLETED, FIXED/VERIFIED)
**Original implementation (completed earlier)**
- Settings UI: password change, SMTP settings save + test email, ayan.sk embed snippet.
- Implemented a custom dependency-free SMTP client.

**Critical bug fix (COMPLETED; verified iteration_7): SMTP port/encryption mismatch**
- **Problem:** Port 465 selected but delivery failed.
- **Root cause:** encryption defaulted to STARTTLS.
- **Fix:** Added `smtp_encryption_for_port()` helper in `api/helpers.php` and used it consistently.

**User-driven change (COMPLETED; verified iteration_8): Remove SMTP UI and move SMTP config to `api/config.php`**
- **Reason:** User requested config-file-only setup.
- **Change:**
  - Added SMTP constants in `api/config.php` (`SMTP_HOST/PORT/USERNAME/PASSWORD/FROM...`).
  - Removed SMTP card and JS from `webadmin/settings.php`.
  - Deleted `api/admin_settings.php` endpoint.

**Latest user-driven change (COMPLETED; verified iteration_9): Replace all custom mailing code with PHPMailer**
- **Reason:** Email still not arriving; user requested removing the custom mailing function and using webmail/Gmail SMTP from config.
- **Change:**
  - Vendored **PHPMailer v7.1.1** as plain PHP files (no Composer) under `api/lib/PHPMailer/`.
  - Rewrote `api/contact_submit.php` to send via PHPMailer SMTP using only `SMTP_*` constants from `api/config.php`.
  - Deleted the old custom SMTP mailer file (`api/smtp_mailer.php`).
  - Added `mail_error` column to `contact_submissions` (schema + **auto-migration** in `api/db.php`) so failures persist.
  - Updated `/webadmin/contacts.php` to show the failure reason as a tooltip on the red **Neodoslaný** badge.

**Operational note:** If mail still doesn’t arrive, the admin can now see the exact SMTP rejection reason in `/webadmin/contacts.php` without server log access.

---

### Phase 3E — URL structure: clean URLs + canonical redirects (COMPLETED)
- Implemented clean URLs + legacy `.html` redirects.

**Apache redirect-loop fix (COMPLETED; iteration_6):**
- Legacy redirects guarded by `%{THE_REQUEST}` to avoid infinite loops during internal rewrites.

**Additional Apache fix (COMPLETED; iteration_7):**
- Index legacy redirect preserves query string (required for Page Editor).

---

### Phase 3F — Public UI refinements (COMPLETED)
- Calendar layout refinement.
- Announcements page grid improvements + CTA.
- About page compact layout.
- Footer credit “Made by Mumi-dev.”.

---

### Phase 3G — Cookie/Privacy consent banner (COMPLETED)
- Localized banner with persistence.
- Hidden in embed mode and page editor mode.

---

### Phase 3H — Remove public “Embed this calendar on another site” section (COMPLETED; verified iteration_7)
**User requirement:** Do not show embed snippet publicly; keep it admin-only.

**Steps (implemented)**
- Removed the entire “Embed calendar” section from `aktivity.html`.
- Removed its 3 i18n keys (`activities.embed_section_title`, `activities.embed_section_desc`, `activities.embed_copy`) from all 5 language JSON files.
- The embed snippet remains available **only** in `/webadmin/settings.php`.

---

### Phase 4 — End-to-end testing + hardening (COMPLETED; updated)
**Verification performed**
- `testing_agent_v3` runs:
  - iteration_4: DB auto-install
  - iteration_5: editor/settings/feature validation
  - iteration_6: Apache clean URL redirect-loop fix
  - iteration_7: contact form + editor fixes + remove public embed section
  - iteration_8: SMTP UI removal + config-only SMTP regression
  - **iteration_9: PHPMailer integration + mail_error persistence + tooltip + regression**
- Real Apache regression testing on port 8899.

---

### Phase 5 — Packaging + deployment docs (COMPLETED; updated)
- Updated `DEPLOY_README.md`:
  - SMTP is configured in `api/config.php` only
  - PHPMailer is bundled under `api/lib/PHPMailer/`
  - failed sends show the SMTP error in `/webadmin/contacts.php`
- Rebuilt deployable zip:
  - `/app/kmssk-sk-website.zip` (~1.8MB)

---

## 3) Next Actions (UPDATED)
**Deployment / post-launch (recommended):**
1. Upload the **new** `/app/kmssk-sk-website.zip` contents to Websupport (best: full replace/upload).
   - At minimum upload: `.htaccess`, `aktivity.html`, `i18n/*.json`, `api/helpers.php`, `api/db.php`, `api/schema.sql`, `api/config.php`, `api/contact_submit.php`, `api/lib/PHPMailer/*`, `webadmin/settings.php`, `webadmin/contacts.php`.
2. Ensure Websupport MySQL database + user exists and credentials match `api/config.php`.
3. **SMTP setup (config-file only):**
   - Edit `api/config.php` and fill `SMTP_HOST/SMTP_PORT/SMTP_USERNAME/SMTP_PASSWORD/SMTP_FROM_EMAIL/...`.
   - Confirm SMTP credentials by logging into the mailbox and ensuring SMTP/external client access is enabled (provider-side).
   - Submit the real contact form on `/contact` to confirm delivery.
   - If it fails, check `/webadmin/contacts.php` and hover the **Neodoslaný** badge to see the exact SMTP error.
4. Open `https://kmssk.sk/` once to trigger auto-install (tables + one-time admin password generation).
5. In Websupport File Manager, open `api/admin_credentials.log` to get the generated admin password.
6. Log into `/webadmin/` (username `admin`), go to **Nastavenia**:
   - change password immediately
7. Verify in production:
   - Contact form: stores + emails via SMTP
   - Page Editor: Home page click-to-edit + image upload/revert
   - Clean URLs/redirects (no loops)
   - `/activities` no longer shows any embed snippet publicly
8. Verify embedding still works on **ayan.sk** using the admin-only embed snippet.
9. If SSL is active, uncomment HTTPS redirect in `.htaccess`.

---

## 4) Success Criteria (UPDATED)
- All public pages render correctly, are responsive, and pass contrast/readability checks.
- i18n works for SK/EN/RU/DE/AR with smooth transitions; AR is RTL without mirrored layout.
- Homepage popup shows only when a published popup announcement exists; popup translation is independent.
- Calendar UI fetches from `/api` and supports iframe-friendly embed mode.
- Contact form stores submissions in MySQL and delivers email via **SMTP configured in `api/config.php`** (sent via PHPMailer); if SMTP is not configured it falls back to `mail()`.
- If delivery fails, the failure reason is visible in `/webadmin/contacts.php` tooltip (mail_error persisted).
- `/webadmin/` supports secure login + announcement/event CRUD + contact archive.
- Webadmin includes the required navigation sequence with icons:
  - Správy → Oznamy → Kalendár → Editor stránok → Nastavenia.
- Page Editor works:
  - click-to-edit page body text/images
  - rich formatting preserved
  - per-language overrides + revert-to-original
  - image replace/revert
  - edits reflect on live public site.
- Public site does **not** display any “Embed calendar on another site” section; snippet is admin-only.
- Cookie/privacy consent banner works:
  - localized message + buttons
  - stores consent in localStorage
  - appears only once per visitor
  - hidden in embed mode and page editor mode
  - links to `/privacy`.
- Clean URLs are canonical:
  - legacy `.html` URLs 301 redirect to clean URLs
  - clean URLs serve 200 without redirect loops on Apache/Websupport
  - query strings preserved where required (Page Editor)
  - sitemap points to clean URLs.
- Fresh Websupport deployment works with **no manual SQL import**: schema + admin account are created automatically on first run; admin password retrievable from `api/admin_credentials.log` (HTTP-blocked).
- Deliverable is a single zip of `/app/site` ready for Websupport hosting (no build step).

**Status:** Met in local Apache + independently tested (iterations 4, 5, 6, **7**, **8**, **9**). Awaiting final user confirmation on their live Websupport deployment after uploading the latest zip.
