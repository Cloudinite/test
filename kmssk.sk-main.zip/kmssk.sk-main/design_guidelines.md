{
  "project": {
    "name": "kmssk.sk — Komunita moslimov v Slovenskej republike",
    "type": "lightweight nonprofit community portal (static HTML/CSS/vanilla JS + PHP JSON endpoints)",
    "primary_goals": [
      "Make announcements and events easy to find and read (high contrast, mobile-first)",
      "Provide a polished calendar experience (month grid + upcoming list)",
      "Make language switching feel premium (cross-fade) while staying lightweight",
      "Keep performance excellent on slow connections"
    ],
    "hard_constraints": {
      "stack": "No build step. Pure static HTML/CSS/vanilla JS + lightweight PHP endpoints under /api",
      "i18n": "SK default + EN/RU/DE/AR via JSON files",
      "arabic_rule": "Arabic must ONLY flip text direction to RTL; layout must NOT mirror (nav/sidebar/buttons stay in same physical positions)",
      "performance": "Minimal JS libraries; prefer CSS animations; optimize images",
      "testing": "All interactive + key informational elements MUST include data-testid (kebab-case)"
    }
  },

  "visual_personality": {
    "keywords": [
      "calm",
      "trustworthy",
      "community-first",
      "editorial-clean",
      "warm-neutral",
      "modern but respectful"
    ],
    "style_fusion": {
      "layout_principle": "Swiss/editorial rhythm (clear typographic hierarchy + generous whitespace)",
      "surface_style": "soft elevated cards (subtle shadow + warm paper background)",
      "accent_language": "brand-derived evergreen + clay accent (earthy, non-flashy)"
    },
    "avoid": [
      "loud gradients",
      "purple/pink gradients",
      "centered-everything layouts",
      "thin low-contrast text",
      "heavy parallax libraries"
    ]
  },

  "typography": {
    "font_strategy": {
      "latin_primary": {
        "name": "IBM Plex Sans",
        "why": "Highly readable UI font, professional tone, broad Latin coverage",
        "fallbacks": ["system-ui", "-apple-system", "Segoe UI", "Roboto", "Arial", "sans-serif"]
      },
      "arabic_primary": {
        "name": "IBM Plex Sans Arabic",
        "why": "Matches IBM Plex Sans tone; correct Arabic shaping; consistent x-height feel",
        "fallbacks": ["Noto Sans Arabic", "Tahoma", "Arial", "sans-serif"]
      },
      "optional_editorial_heading": {
        "name": "Spectral",
        "usage": "Only for H1/H2 on marketing pages if performance budget allows; otherwise keep headings in IBM Plex Sans",
        "fallbacks": ["Georgia", "serif"]
      },
      "loading": {
        "method": "Google Fonts <link> (no JS)",
        "performance_notes": [
          "Use display=swap",
          "Subset latin + latin-ext; arabic subset only when needed if you can conditionally load per locale",
          "Prefer 400/500/600 weights only"
        ]
      }
    },
    "type_scale_tailwind_equivalent": {
      "h1": "text-4xl sm:text-5xl lg:text-6xl",
      "h2": "text-base md:text-lg",
      "body": "text-sm md:text-base",
      "small": "text-xs"
    },
    "recommended_css_scale": {
      "--fs-900": "clamp(2.25rem, 4vw, 3.5rem)",
      "--fs-800": "clamp(1.5rem, 2.2vw, 2rem)",
      "--fs-700": "1.25rem",
      "--fs-600": "1.125rem",
      "--fs-500": "1rem",
      "--fs-400": "0.9375rem",
      "--fs-300": "0.875rem",
      "--fs-200": "0.8125rem"
    },
    "line_heights": {
      "tight": 1.15,
      "normal": 1.5,
      "relaxed": 1.7
    },
    "letter_spacing": {
      "headings": "-0.01em",
      "buttons": "0.01em"
    }
  },

  "color_system": {
    "notes": [
      "Derived from existing green emblem + earthy accents; tuned for WCAG-friendly contrast on warm light backgrounds.",
      "Primary surfaces are light (paper-like) to maximize readability and avoid the old white-on-white bug.",
      "Gradients are decorative only and must stay under 20% viewport (see gradient rules)."
    ],
    "palette": {
      "paper": "#F7F2EA",
      "surface": "#FFFBF4",
      "surface_2": "#EFE6DA",
      "ink": "#16251E",
      "ink_muted": "#3E5248",
      "border": "#D6C8B8",
      "primary": "#1F5A43",
      "primary_hover": "#174534",
      "accent": "#9A5A2A",
      "accent_soft": "#D7C07A",
      "info": "#1E5A7A",
      "success": "#2F6B4F",
      "warning": "#9A6A2F",
      "danger": "#8A3F3A",
      "focus": "#1D4ED8"
    },
    "semantic_roles": {
      "--bg": "var(--paper)",
      "--fg": "var(--ink)",
      "--fg-muted": "var(--ink-muted)",
      "--card": "var(--surface)",
      "--card-2": "var(--surface_2)",
      "--stroke": "var(--border)",
      "--brand": "var(--primary)",
      "--brand-strong": "var(--primary_hover)",
      "--accent": "var(--accent)",
      "--ring": "var(--focus)"
    },
    "contrast_rules": {
      "body_text_on_bg": "Use --fg on --bg or --card only (never white text on light surfaces)",
      "muted_text": "Use --fg-muted only for secondary metadata; never for essential info",
      "buttons": "Primary button uses white text on --brand (check contrast; keep brand dark enough)",
      "links": "Links use --brand-strong; hover shifts to --accent"
    },
    "allowed_gradients": {
      "decorative_hero_wash": "linear-gradient(135deg, rgba(31,90,67,0.10), rgba(215,192,122,0.10), rgba(154,90,42,0.06))",
      "notes": [
        "Use only as section background overlay, not behind paragraphs.",
        "Never exceed 20% viewport coverage."
      ]
    }
  },

  "design_tokens_css": {
    "file_recommendation": "Create /assets/css/tokens.css and load it before site.css",
    "tokens": "/* tokens.css */\n:root{\n  --bg:#F7F2EA;\n  --fg:#16251E;\n  --fg-muted:#3E5248;\n  --card:#FFFBF4;\n  --card-2:#EFE6DA;\n  --stroke:#D6C8B8;\n  --brand:#1F5A43;\n  --brand-strong:#174534;\n  --accent:#9A5A2A;\n  --accent-soft:#D7C07A;\n  --info:#1E5A7A;\n  --success:#2F6B4F;\n  --warning:#9A6A2F;\n  --danger:#8A3F3A;\n  --ring:#1D4ED8;\n\n  --font-latin:\"IBM Plex Sans\",system-ui,-apple-system,\"Segoe UI\",Roboto,Arial,sans-serif;\n  --font-arabic:\"IBM Plex Sans Arabic\",\"Noto Sans Arabic\",Tahoma,Arial,sans-serif;\n\n  --fs-900:clamp(2.25rem,4vw,3.5rem);\n  --fs-800:clamp(1.5rem,2.2vw,2rem);\n  --fs-700:1.25rem;\n  --fs-600:1.125rem;\n  --fs-500:1rem;\n  --fs-400:0.9375rem;\n  --fs-300:0.875rem;\n  --fs-200:0.8125rem;\n\n  --lh-tight:1.15;\n  --lh-normal:1.5;\n  --lh-relaxed:1.7;\n\n  --space-1:0.25rem;\n  --space-2:0.5rem;\n  --space-3:0.75rem;\n  --space-4:1rem;\n  --space-5:1.25rem;\n  --space-6:1.5rem;\n  --space-8:2rem;\n  --space-10:2.5rem;\n  --space-12:3rem;\n  --space-16:4rem;\n\n  --radius-1:10px;\n  --radius-2:14px;\n  --radius-3:18px;\n\n  --shadow-1:0 1px 2px rgba(22,37,30,.08),0 6px 18px rgba(22,37,30,.06);\n  --shadow-2:0 2px 4px rgba(22,37,30,.10),0 14px 30px rgba(22,37,30,.10);\n\n  --ease-out:cubic-bezier(.16,1,.3,1);\n  --ease-in:cubic-bezier(.7,0,.84,0);\n  --dur-1:120ms;\n  --dur-2:180ms;\n  --dur-3:260ms;\n  --dur-4:420ms;\n}\n\nhtml{color-scheme:light;}\nbody{background:var(--bg);color:var(--fg);font-family:var(--font-latin);font-size:var(--fs-400);line-height:var(--lh-relaxed);}\nhtml[lang^=\"ar\"] body{font-family:var(--font-arabic);}\n\n:focus-visible{outline:3px solid var(--ring);outline-offset:2px;}\n\n::selection{background:rgba(31,90,67,.18);}\n"
  },

  "layout_grid": {
    "container": {
      "max_width": "1120px",
      "padding": "16px mobile, 24px tablet, 32px desktop",
      "css": ".container{max-width:1120px;margin:0 auto;padding:0 16px;}@media(min-width:768px){.container{padding:0 24px;}}@media(min-width:1024px){.container{padding:0 32px;}}"
    },
    "page_sections": {
      "vertical_rhythm": "Use 48–72px between major sections on desktop; 32–48px on mobile",
      "section_header_pattern": "Small eyebrow label (uppercase) + H2 + 1–2 line description"
    }
  },

  "components": {
    "header_nav": {
      "description": "Sticky header with subtle blur + border; compact height; clear active state; no layout mirroring in Arabic.",
      "structure": [
        "Left: logo mark + site name",
        "Center (desktop): nav links",
        "Right: primary CTA (Contact) + hamburger on mobile"
      ],
      "css_notes": [
        "Use position: sticky; top:0; z-index:50",
        "Background: rgba(255,251,244,0.82) with backdrop-filter: blur(10px) (fallback to solid on unsupported)",
        "Border-bottom: 1px solid var(--stroke)"
      ],
      "data_testids": {
        "header": "site-header",
        "logo_link": "site-logo-link",
        "nav": "site-nav",
        "hamburger": "mobile-menu-open-button",
        "cta": "header-contact-cta"
      }
    },

    "mobile_drawer_sidebar": {
      "description": "Hamburger opens slide-out sidebar from the same physical side for all languages (recommend right side for thumb reach).",
      "behavior": [
        "Overlay scrim fades in",
        "Drawer slides in (translateX) with ease-out",
        "Focus trap + ESC closes",
        "Body scroll locked"
      ],
      "css_scaffold": "/* Drawer */\n.drawer-scrim{position:fixed;inset:0;background:rgba(22,37,30,.42);opacity:0;pointer-events:none;transition:opacity var(--dur-3) var(--ease-out);}\n.drawer{position:fixed;top:0;right:0;height:100%;width:min(86vw,360px);background:var(--card);border-left:1px solid var(--stroke);transform:translateX(12px);translate:100% 0;opacity:0;box-shadow:var(--shadow-2);transition:opacity var(--dur-3) var(--ease-out), translate var(--dur-3) var(--ease-out);}\n.drawer[data-open=\"true\"]{opacity:1;translate:0 0;}\n.drawer-scrim[data-open=\"true\"]{opacity:1;pointer-events:auto;}\n",
      "data_testids": {
        "drawer": "mobile-nav-drawer",
        "drawer_close": "mobile-menu-close-button",
        "drawer_link_prefix": "mobile-nav-link"
      }
    },

    "floating_action_pair": {
      "description": "Always-visible floating pair: Scroll-to-top + Language switcher immediately next to it. Keep physical placement constant across locales.",
      "placement": "bottom-right (recommended). Use safe-area inset on iOS.",
      "spec": {
        "size": "44–48px square buttons",
        "radius": "14px",
        "style": "solid surface with border + shadow; primary icon color uses --brand",
        "hover": "lift + subtle shadow increase",
        "active": "press scale 0.98"
      },
      "css_scaffold": ".fab-rail{position:fixed;right:16px;bottom:16px;display:flex;gap:10px;z-index:60;padding-bottom:env(safe-area-inset-bottom);}\n.fab{width:48px;height:48px;border-radius:14px;background:rgba(255,251,244,.92);border:1px solid var(--stroke);box-shadow:var(--shadow-1);display:grid;place-items:center;color:var(--brand-strong);transition:box-shadow var(--dur-2) var(--ease-out), background var(--dur-2) var(--ease-out);}\n.fab:hover{box-shadow:var(--shadow-2);background:var(--card);}\n.fab:active{transform:scale(.98);}\n",
      "data_testids": {
        "scroll_top": "scroll-to-top-button",
        "language": "site-language-button"
      }
    },

    "language_switcher": {
      "description": "Site-wide language switcher opens a compact menu (SK/EN/RU/DE/AR). Switching triggers cross-fade of main content.",
      "ui": "Use a small popover/menu anchored to the floating language button; show current language code.",
      "crossfade": {
        "approach": "Wrap main content in #app-content; on language change add data-i18n-state=\"out\" then swap strings then set \"in\".",
        "css": "#app-content{opacity:1;transform:translateY(0);transition:opacity var(--dur-4) var(--ease-out), transform var(--dur-4) var(--ease-out);}\n#app-content[data-i18n-state=\"out\"]{opacity:0;transform:translateY(4px);}\n"
      },
      "rtl_text_only": {
        "rule": "Set dir=rtl only on text containers, not on html/body.",
        "implementation": "When lang is ar, add dir=rtl to elements with [data-i18n-dir]. Keep layout wrappers dir=ltr.",
        "css": "[data-i18n-dir][dir=rtl]{text-align:right;}"
      },
      "data_testids": {
        "menu": "language-menu",
        "option_prefix": "language-option"
      }
    },

    "homepage_announcement_modal": {
      "description": "Homepage loads a modal if a new admin-published announcement is flagged. Modal has its OWN mini translate control independent from site-wide switcher.",
      "behavior": [
        "Open after first paint (setTimeout 250ms) to avoid layout jank",
        "Trap focus; ESC closes; close button always visible",
        "Mini language toggle affects only modal content"
      ],
      "visual": {
        "layout": "Title + date badge + body + CTA link + mini language toggle in header row",
        "accent": "Use a thin left border or top bar in --accent-soft (not gradient)"
      },
      "data_testids": {
        "modal": "announcement-modal",
        "close": "announcement-modal-close-button",
        "mini_language": "announcement-modal-language-button",
        "title": "announcement-modal-title",
        "body": "announcement-modal-body"
      }
    },

    "cards": {
      "base_card": {
        "css": ".card{background:var(--card);border:1px solid var(--stroke);border-radius:var(--radius-2);box-shadow:var(--shadow-1);}\n.card:hover{box-shadow:var(--shadow-2);}\n",
        "notes": ["No transition: all. Only transition box-shadow/background/border-color."]
      },
      "announcement_card": {
        "pattern": "Badge (category) + title + excerpt + meta row (date/source) + link",
        "states": ["unread uses accent-soft dot", "urgent uses danger border-left"]
      },
      "event_card": {
        "pattern": "Date pill + title + location + tags + CTA (Details)",
        "micro": "Hover lifts 2px; CTA underline anim"
      },
      "education_coming_soon_card": {
        "pattern": "Icon + title + short copy + disabled CTA",
        "note": "Disabled must still be readable; use aria-disabled=true"
      }
    },

    "faq_accordion": {
      "component_path": "/app/frontend/src/components/ui/accordion.jsx",
      "behavior": "Chevron rotates; content expands with height animation; keep tap targets large.",
      "data_testids": {
        "item_prefix": "faq-item",
        "trigger_prefix": "faq-trigger",
        "content_prefix": "faq-content"
      }
    },

    "calendar_page": {
      "description": "Month grid + upcoming/ongoing list. Mobile-first: list first, month grid collapsible or below.",
      "month_grid": {
        "spec": [
          "7-column grid on desktop",
          "On mobile: keep 7 columns but reduce cell content; show dots for events",
          "Today highlight: subtle ring in --brand",
          "Selected day: filled soft background in rgba(31,90,67,0.10)"
        ],
        "empty_state": "If no events: show calm empty card with CTA to contact organizers"
      },
      "upcoming_list": {
        "spec": [
          "Cards grouped by week",
          "Sticky mini filter row (All / Lectures / Family / Youth)"
        ]
      },
      "embed_variant": {
        "rules": [
          "No header/footer",
          "No heavy shadows; use border-only cards",
          "Max width 100%; responsive height",
          "Expose query param ?embed=1 to switch styles"
        ],
        "css": "body[data-embed=\"true\"]{background:transparent;}body[data-embed=\"true\"] .site-header,body[data-embed=\"true\"] .site-footer,body[data-embed=\"true\"] .fab-rail{display:none !important;}body[data-embed=\"true\"] .card{box-shadow:none;}"
      },
      "data_testids": {
        "month": "calendar-month-grid",
        "day_prefix": "calendar-day",
        "list": "calendar-upcoming-list",
        "filter": "calendar-filter"
      }
    },

    "forms": {
      "contact_form": {
        "fields": ["name", "email", "phone", "message"],
        "rules": [
          "Labels always visible (no placeholder-only)",
          "Error text in --danger with icon",
          "Success state uses --success",
          "Inputs min-height 44px"
        ],
        "css": ".input{width:100%;min-height:44px;border-radius:12px;border:1px solid var(--stroke);background:var(--card);padding:10px 12px;color:var(--fg);transition:border-color var(--dur-2) var(--ease-out), box-shadow var(--dur-2) var(--ease-out);}\n.input:focus{border-color:rgba(31,90,67,.55);box-shadow:0 0 0 4px rgba(29,78,216,.18);outline:none;}\n"
      },
      "data_testids": {
        "form": "contact-form",
        "submit": "contact-form-submit-button",
        "name": "contact-form-name-input",
        "email": "contact-form-email-input",
        "phone": "contact-form-phone-input",
        "message": "contact-form-message-textarea",
        "error": "contact-form-error",
        "success": "contact-form-success"
      }
    },

    "buttons": {
      "variants": {
        "primary": {
          "style": "solid brand",
          "css": ".btn-primary{background:var(--brand);color:#fff;border:1px solid rgba(0,0,0,0);border-radius:12px;padding:10px 14px;font-weight:600;transition:background var(--dur-2) var(--ease-out), box-shadow var(--dur-2) var(--ease-out);}\n.btn-primary:hover{background:var(--brand-strong);box-shadow:var(--shadow-1);}\n.btn-primary:active{transform:scale(.98);}\n"
        },
        "secondary": {
          "style": "surface + border",
          "css": ".btn-secondary{background:var(--card);color:var(--fg);border:1px solid var(--stroke);border-radius:12px;padding:10px 14px;font-weight:600;transition:border-color var(--dur-2) var(--ease-out), box-shadow var(--dur-2) var(--ease-out), background var(--dur-2) var(--ease-out);}\n.btn-secondary:hover{border-color:rgba(31,90,67,.35);box-shadow:var(--shadow-1);}\n"
        },
        "ghost": {
          "style": "text button",
          "css": ".btn-ghost{background:transparent;color:var(--brand-strong);border-radius:12px;padding:10px 12px;font-weight:600;transition:background var(--dur-2) var(--ease-out);}\n.btn-ghost:hover{background:rgba(31,90,67,.08);}\n"
        }
      },
      "sizes": {
        "sm": "min-height 36px",
        "md": "min-height 44px",
        "lg": "min-height 48px"
      }
    },

    "footer": {
      "description": "Warm, quiet footer with clear link groups + contact email. No gradients.",
      "spec": [
        "Top border 1px stroke",
        "3 columns desktop, stacked mobile",
        "Small print uses --fg-muted but keep contrast"
      ],
      "data_testids": {
        "footer": "site-footer",
        "privacy": "footer-privacy-link",
        "contact": "footer-contact-link"
      }
    }
  },

  "motion": {
    "principles": [
      "Motion should clarify state changes (open/close, hover, language swap)",
      "Keep durations short; use ease-out",
      "Respect prefers-reduced-motion"
    ],
    "durations": {
      "hover": "120–180ms",
      "drawer": "260ms",
      "page_reveal": "420ms",
      "language_crossfade": "420ms"
    },
    "page_transition_feel": {
      "approach": "On navigation, fade out main content then swap page then fade in (no SPA required if you keep it per-page: use CSS animation on body class + small JS).",
      "css": "body{opacity:1;}body[data-page-state=\"out\"]{opacity:0;transition:opacity var(--dur-4) var(--ease-out);}"
    },
    "reduced_motion": {
      "css": "@media (prefers-reduced-motion: reduce){*{scroll-behavior:auto !important;} .drawer,.drawer-scrim,#app-content{transition:none !important;}}"
    }
  },

  "rtl_safe_rules": {
    "must_not_mirror": [
      "Header layout (logo left, nav center, actions right)",
      "Mobile drawer side (always right)",
      "Floating buttons bottom-right",
      "Calendar grid alignment and controls placement"
    ],
    "may_flip": [
      "Text direction inside paragraphs, headings, list items",
      "Inline icon placement inside text blocks (use logical properties carefully)"
    ],
    "implementation": {
      "do_not_set": "Do NOT set dir=rtl on html/body.",
      "do_set": "Set dir=rtl only on elements that contain translated Arabic strings: <p data-i18n-dir>...",
      "css_helpers": [
        ".text-rtl{direction:rtl;text-align:right;unicode-bidi:plaintext;}",
        ".text-ltr{direction:ltr;text-align:left;unicode-bidi:plaintext;}"
      ]
    }
  },

  "accessibility": {
    "requirements": [
      "WCAG AA contrast for text and UI",
      "Visible focus states (3px ring)",
      "44px minimum touch targets",
      "Semantic HTML (nav/main/footer, headings in order)",
      "Modal focus trap + aria-modal + aria-labelledby",
      "Drawer uses aria-expanded + aria-controls"
    ],
    "common_bug_fix": "Never use white text on light backgrounds; audit all buttons/badges for contrast.",
    "aria_notes": {
      "language_menu": "Use role=menu and role=menuitemradio with aria-checked",
      "calendar": "Use aria-label on day buttons like '15 March, 2 events'"
    }
  },

  "image_urls": {
    "hero_background_or_section": [
      {
        "url": "https://images.unsplash.com/photo-1540575467063-178a50c2df87?crop=entropy&cs=srgb&fm=jpg&ixlib=rb-4.1.0&q=85",
        "description": "Soft-focus community gathering (use as subtle hero side image or section image; ensure modest, respectful crop)",
        "category": "home-hero"
      }
    ],
    "events_teaser": [
      {
        "url": "https://images.unsplash.com/photo-1515168833906-d2a3b82b302a?crop=entropy&cs=srgb&fm=jpg&ixlib=rb-4.1.0&q=85",
        "description": "Lecture/community talk vibe for events teaser card",
        "category": "events"
      }
    ],
    "about_or_history": [
      {
        "url": "https://images.unsplash.com/photo-1529070538774-1843cb3265df?crop=entropy&cs=srgb&fm=jpg&ixlib=rb-4.1.0&q=85",
        "description": "Education/reading image for About/Education sections",
        "category": "about-education"
      }
    ]
  },

  "component_path": {
    "shadcn_reference_only": {
      "note": "Project is static HTML/vanilla JS; these paths are for design reference only (do not import React components).",
      "accordion": "/app/frontend/src/components/ui/accordion.jsx",
      "dialog": "/app/frontend/src/components/ui/dialog.jsx",
      "drawer": "/app/frontend/src/components/ui/drawer.jsx",
      "calendar": "/app/frontend/src/components/ui/calendar.jsx",
      "button": "/app/frontend/src/components/ui/button.jsx",
      "card": "/app/frontend/src/components/ui/card.jsx",
      "sonner": "/app/frontend/src/components/ui/sonner.jsx"
    }
  },

  "instructions_to_main_agent": {
    "implementation_plan": [
      "Create tokens.css (above) + site.css that uses tokens for all components.",
      "Implement sticky header + mobile drawer with focus trap and ESC close.",
      "Implement floating FAB rail (scroll-to-top + language) always visible.",
      "Implement i18n loader: fetch locale JSON, apply to [data-i18n-key] nodes; cross-fade #app-content.",
      "Arabic: apply dir=rtl ONLY to nodes with [data-i18n-dir]; do not mirror layout.",
      "Homepage: fetch latest announcement; if flagged new, open modal; modal has independent mini language toggle.",
      "Calendar page: month grid + upcoming list; add embed mode via ?embed=1 with stripped styles.",
      "Add data-testid to every interactive element and key info blocks per component specs."
    ],
    "performance": [
      "Prefer system font fallback if Google Fonts blocked; keep font weights minimal.",
      "Use <img loading=\"lazy\"> and responsive sizes; compress images.",
      "Avoid heavy JS; no animation libraries."
    ],
    "seo": [
      "Use semantic HTML and real links (not JS-only navigation).",
      "Ensure headings are meaningful and localized."
    ]
  },

  "appendix_general_ui_ux_design_guidelines": "<General UI UX Design Guidelines>\n    - You must **not** apply universal transition. Eg: `transition: all`. This results in breaking transforms. Always add transitions for specific interactive elements like button, input excluding transforms\n    - You must **not** center align the app container, ie do not add `.App { text-align: center; }` in the css file. This disrupts the human natural reading flow of text\n   - NEVER: use AI assistant Emoji characters like`🤖🧠💭💡🔮🎯📚🎭🎬🎪🎉🎊🎁🎀🎂🍰🎈🎨🎰💰💵💳🏦💎🪙💸🤑📊📈📉💹🔢🏆🥇 etc for icons. Always use **FontAwesome cdn** or **lucid-react** library already installed in the package.json\n\n **GRADIENT RESTRICTION RULE**\nNEVER use dark/saturated gradient combos (e.g., purple/pink) on any UI element.  Prohibited gradients: blue-500 to purple 600, purple 500 to pink-500, green-500 to blue-500, red to pink etc\nNEVER use dark gradients for logo, testimonial, footer etc\nNEVER let gradients cover more than 20% of the viewport.\nNEVER apply gradients to text-heavy content or reading areas.\nNEVER use gradients on small UI elements (<100px width).\nNEVER stack multiple gradient layers in the same viewport.\n\n**ENFORCEMENT RULE:**\n    • Id gradient area exceeds 20% of viewport OR affects readability, **THEN** use solid colors\n\n**How and where to use:**\n   • Section backgrounds (not content backgrounds)\n   • Hero section header content. Eg: dark to light to dark color\n   • Decorative overlays and accent elements only\n   • Hero section with 2-3 mild color\n   • Gradients creation can be done for any angle say horizontal, vertical or diagonal\n\n- For AI chat, voice application, **do not use purple color. Use color like light green, ocean blue, peach orange etc**\n\n</Font Guidelines>\n\n- Every interaction needs micro-animations - hover states, transitions, parallax effects, and entrance animations. Static = dead. \n   \n- Use 2-3x more spacing than feels comfortable. Cramped designs look cheap.\n\n- Subtle grain textures, noise overlays, custom cursors, selection states, and loading animations: separates good from extraordinary.\n   \n- Before generating UI, infer the visual style from the problem statement (palette, contrast, mood, motion) and immediately instantiate it by setting global design tokens (primary, secondary/accent, background, foreground, ring, state colors), rather than relying on any library defaults. Don't make the background dark as a default step, always understand problem first and define colors accordingly\n    Eg: - if it implies playful/energetic, choose a colorful scheme\n           - if it implies monochrome/minimal, choose a black–white/neutral scheme\n\n**Component Reuse:**\n\t- Prioritize using pre-existing components from src/components/ui when applicable\n\t- Create new components that match the style and conventions of existing components when needed\n\t- Examine existing components to understand the project's component patterns before creating new ones\n\n**IMPORTANT**: Do not use HTML based component like dropdown, calendar, toast etc. You **MUST** always use `/app/frontend/src/components/ui/ ` only as a primary components as these are modern and stylish component\n\n**Best Practices:**\n\t- Use Shadcn/UI as the primary component library for consistency and accessibility\n\t- Import path: ./components/[component-name]\n\n**Export Conventions:**\n\t- Components MUST use named exports (export const ComponentName = ...)\n\t- Pages MUST use default exports (export default function PageName() {...})\n\n**Toasts:**\n  - Use `sonner` for toasts\"\n  - Sonner component are located in `/app/src/components/ui/sonner.tsx`\n\nUse 2–4 color gradients, subtle textures/noise overlays, or CSS-based noise to avoid flat visuals.\n</General UI UX Design Guidelines>"
}
